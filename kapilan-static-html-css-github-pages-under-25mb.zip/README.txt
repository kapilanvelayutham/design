KAPILAN PORTFOLIO — STATIC HTML/CSS VERSION

This site uses plain HTML and CSS. It does not require Node.js, React, a build step, a backend, or JSON data files.

FILES
- index.html: portfolio homepage
- styles.css: all homepage styling and responsive layout
- assets/: images, fonts, PDFs, and standalone HTML case studies
- 404.html: simple fallback page
- .nojekyll: tells GitHub Pages not to run Jekyll processing

PUBLISH ON GITHUB PAGES
1. Extract this ZIP.
2. Copy the CONTENTS of this folder (index.html, styles.css, assets, etc.) into the ROOT of your GitHub repository named kapilan.github.io. Do not put them inside another nested folder. Do not delete the repository's hidden .git folder.
3. Commit and push/publish the changes with GitHub Desktop.
4. In the repository on GitHub, open Settings > Pages.
5. Under Build and deployment, choose Deploy from a branch; select main and /(root), then Save.
6. Wait a few minutes and open https://kapilan.github.io.

All internal links are relative, so the page does not rely on a server-side app. The standalone case-study pages and PDFs are inside assets/.
